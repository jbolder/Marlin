#
# buildroot/share/PlatformIO/scripts/mks_robin_e3p.py
#
import robin
robin.prepare("0x08007000", "mks_robin_e3p.ld", "Robin_e3p.bin")
